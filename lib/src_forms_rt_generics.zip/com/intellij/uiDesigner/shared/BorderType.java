/*
 * Copyright (c) 2004 JetBrains s.r.o. All  Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 *
 * Neither the name of JetBrains or IntelliJ IDEA
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBRAINS AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL JETBRAINS OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF JETBRAINS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 */
package com.intellij.uiDesigner.shared;

import javax.swing.*;
import javax.swing.border.Border;

/**
 * @author Vladimir Kondratyev
 */
public final class BorderType {
  public static final BorderType NONE = new BorderType("none", "None",null,null);
  public static final BorderType BEVEL_LOWERED = new BorderType("bevel-lowered", "Bevel Lowered", BorderFactory.createLoweredBevelBorder(), "createLoweredBevelBorder");
  public static final BorderType BEVEL_RAISED = new BorderType("bevel-raised", "Bevel Raised", BorderFactory.createRaisedBevelBorder(), "createRaisedBevelBorder");
  public static final BorderType ETCHED = new BorderType("etched", "Etched", BorderFactory.createEtchedBorder(), "createEtchedBorder");

  private final String myId;
  private final String myName;
  private final Border myBorder;
  private final String myBorderFactoryMethodName;

  private BorderType(final String id,final String name,final Border border,final String borderFactoryMethodName){
    myId=id;
    myName=name;
    myBorder=border;
    myBorderFactoryMethodName = borderFactoryMethodName;
  }

  public String getId(){
    return myId;
  }

  public String getName(){
    return myName;
  }

  public Border createBorder(final String title){
    if (title != null) {
      return BorderFactory.createTitledBorder(myBorder, title);
    }
    else {
      return myBorder;
    }
  }

  public String getBorderFactoryMethodName(){
    return myBorderFactoryMethodName;
  }

  public boolean equals(final Object o){
    if (o instanceof BorderType){
      return myId.equals(((BorderType)o).myId);
    }
    return false;
  }

  public int hashCode(){
    return 0;
  }

  public static BorderType valueOf(final String name){
    if(NONE.getId().equals(name)){
      return NONE;
    }
    else if(BEVEL_LOWERED.getId().equals(name)){
      return BEVEL_LOWERED;
    }
    else if(BEVEL_RAISED.getId().equals(name)){
      return BEVEL_RAISED;
    }
    else if(ETCHED.getId().equals(name)){
      return ETCHED;
    }
    else{
      throw new IllegalArgumentException("unknown type: "+name);
    }
  }
}
