/*
 * Copyright (c) 2004 JetBrains s.r.o. All  Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 *
 * Neither the name of JetBrains or IntelliJ IDEA
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBRAINS AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL JETBRAINS OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF JETBRAINS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 */
package com.intellij.uiDesigner.compiler;

import com.intellij.uiDesigner.lw.LwRootContainer;
import org.apache.bcel.Constants;
import org.apache.bcel.Repository;
import org.apache.bcel.classfile.ClassFormatException;
import org.apache.bcel.classfile.ClassParser;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Anton Katilin
 */
public final class CodeGenerator {
  // PLEASE DO NOT USE GENERICS IN THIS FILE AS IT IS USED IN JAVAC2 ANT TASK THAT SHOULD BE RUNNABLE WITH JDK 1.3

  public static final String SETUP_METHOD_NAME = "$$$setupUI$$$";
  private final LwRootContainer myRootContainer;
  private final ArrayList myErrors;
  private final ArrayList myWarnings;
  private final File myClassFile;
  private final ClassLoader myLoader;

  public CodeGenerator(final LwRootContainer rootContainer, final File classFile, final ClassLoader loader) {
    if (loader == null){
      throw new IllegalArgumentException("loader cannot be null");
    }
    if (rootContainer == null){
      throw new IllegalArgumentException("rootContainer cannot be null");
    }
    myRootContainer = rootContainer;
    myClassFile = classFile;
    myLoader = loader;

    myErrors = new ArrayList();
    myWarnings = new ArrayList();
  }

  public void patch() {
    final String classToBind = myRootContainer.getClassToBind();
    if (classToBind == null){
      myWarnings.add("No class to bind specified");
      return;
    }

    if (!myClassFile.exists()) {
      myErrors.add("Class to bind does not exist: " + classToBind);
      return;
    }

    final JavaClass javaClass;
    try {
      final ClassParser classParser = new ClassParser(myClassFile.getPath());
      javaClass = classParser.parse();
      // [jeka] important! Need this in order to resolve other classes in the project (e.g. superclasses)
      javaClass.setRepository(getActiveBCELRepository());
    }
    catch (IOException e) {
      myErrors.add("Cannot parse class file " + myClassFile.getPath() + ": " + e.toString());
      return;
    }
    catch (ClassFormatException e) {
      myErrors.add("Class format exception: " + e.getMessage() + " File: " + myClassFile.getPath());
      return;
    }
    catch (Exception e) {
      myErrors.add("Incorrect version of BCEL library: " + e.getMessage());
      return;
    }

    final JavaClass result;
    try {
      result = instrumentClass(javaClass, myRootContainer, myLoader);
    }
    catch (CodeGenerationException e) {
      myErrors.add(e.getMessage());
      return;
    }

    // save patched classfile
    try {
      result.dump(myClassFile.getPath());
    }
    catch (Exception e) {
      myErrors.add(e.getMessage() != null ? e.getMessage() : null);
    }
  }
  
  public String[] getErrors() {
    return (String[])myErrors.toArray(new String[myErrors.size()]);
  }

  public String[] getWarnings() {
    return (String[])myWarnings.toArray(new String[myWarnings.size()]);
  }

  private static JavaClass instrumentClass(
    final JavaClass javaClass,
    final LwRootContainer rootContainer,
    final ClassLoader loader
  ) throws CodeGenerationException{
    // correctly handles $'s in inner class names
    final String classToBind = javaClass.getClassName();

    // try to find if setup method already exists
    int setupMethodPosition = -1;
    {
    final Method[] methods = javaClass.getMethods();
    for (int i = 0; i < methods.length; i++) {
      final Method method = methods[i];
      if (SETUP_METHOD_NAME.equals(method.getName())) {
        setupMethodPosition = i;
        break;
      }
    }
    }

    // generate setup method 
    final ClassGen classGen = new ClassGen(javaClass);
    final ConstantPoolGen constantPool = classGen.getConstantPool();
    final InstructionFactory instructionFactory = new InstructionFactory(classGen);

    final MethodGen setupMethodGen = new MethodGen(
      Constants.ACC_PRIVATE, Type.VOID, Type.NO_ARGS, new String[0], SETUP_METHOD_NAME,
      classToBind, new InstructionList(), constantPool
    );

    final FormByteCodeGenerator codeGenerator = new FormByteCodeGenerator(
      rootContainer, 
      instructionFactory, 
      setupMethodGen.getInstructionList(), 
      constantPool, 
      classToBind, 
      1, 
      javaClass
    );
    codeGenerator.generate(loader);
    setupMethodGen.getInstructionList().append(InstructionFactory.createReturn(Type.VOID));

    setupMethodGen.setMaxStack();
    setupMethodGen.setMaxLocals();

    if (setupMethodPosition != -1) {
      classGen.setMethodAt(setupMethodGen.getMethod(), setupMethodPosition);
    }
    else {
      classGen.addMethod(setupMethodGen.getMethod());
    }

    // invoke setup method in all constructors  
    if (setupMethodPosition == -1){
      final Method[] methods = classGen.getMethods();
      methods: for (int i = 0; i < methods.length; i++) {
        final Method method = methods[i];
        if (!"<init>".equals(method.getName())){
          continue;
        }

        final MethodGen constructorGen = new MethodGen(method, javaClass.getClassName(), classGen.getConstantPool());
        final InstructionList constructorInstructions = constructorGen.getInstructionList();

        final InstructionHandle[] instructionHandles = constructorInstructions.getInstructionHandles();
        for (int j = 0; j < instructionHandles.length; j++) {
          final Instruction instruction = instructionHandles[j].getInstruction();
          if (!(instruction instanceof InvokeInstruction)){
            continue;
          }
          if (!"invokespecial".equals(instruction.getName())){
            continue;
          }
          final InvokeInstruction invokeInstruction = (InvokeInstruction)instruction;

          final String className = invokeInstruction.getClassName(classGen.getConstantPool());
          if (!className.equals(classToBind) && !className.equals(classGen.getSuperclassName())) {
            // skip new inside super(...) or this(...)
            continue;
          }
          
          if (className.equals(classToBind)) {
            // do not call setup in constructors that call other constructors of this class:
            // A() {
            //    this(10);
            //    // do not add here
            // }
            // A(int i) {
            //    // add here
            // }
            continue methods;
          }
          
          final InstructionList callSetupList = new InstructionList();
          callSetupList.append(InstructionFactory.createLoad(Type.OBJECT, 0));
          callSetupList.append(instructionFactory.createInvoke(classToBind, SETUP_METHOD_NAME, Type.VOID, Type.NO_ARGS, Constants.INVOKESPECIAL));
          constructorInstructions.append(instructionHandles[j], callSetupList);
      
          constructorGen.setMaxStack();
          constructorGen.setMaxLocals();
          classGen.setMethodAt(constructorGen.getMethod(), i);
          break;
        }
      }
    }

    return classGen.getJavaClass();
  }

  public static org.apache.bcel.util.Repository getActiveBCELRepository() throws Exception {
    final Class aClass = Repository.class;
    final java.lang.reflect.Field field = aClass.getDeclaredField("_repository");
    field.setAccessible(true);
    return (org.apache.bcel.util.Repository)field.get(null);
  }
}
