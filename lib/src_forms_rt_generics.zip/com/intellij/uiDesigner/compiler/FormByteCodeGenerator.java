/*
 * Copyright (c) 2004 JetBrains s.r.o. All  Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 *
 * Neither the name of JetBrains or IntelliJ IDEA
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBRAINS AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL JETBRAINS OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF JETBRAINS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 */
package com.intellij.uiDesigner.compiler;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.SupportCode;
import com.intellij.uiDesigner.lw.*;
import com.intellij.uiDesigner.shared.BorderType;
import org.apache.bcel.Constants;
import org.apache.bcel.Repository;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.generic.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;

final class FormByteCodeGenerator {
  // PLEASE DO NOT USE GENERICS IN THIS FILE AS IT IS USED IN JAVAC2 ANT TASK THAT SHOULD BE RUNNABLE WITH JDK 1.3

  private final LwRootContainer myRootContainer;

  private final InstructionFactory myFactory;
  private final ConstantPoolGen myConstantPoolGen;
  private final String myClassToBind;
  private final JavaClass myClassBeingPatched;
  private int myTempVariableCount;
  private final HashMap myComponent2TempVariable;
  private final InstructionList myList;
  
  public FormByteCodeGenerator(
    final LwRootContainer rootContainer,
    final InstructionFactory instructionFactory,
    final InstructionList instructionList, final ConstantPoolGen constantPoolGen,
    final String classToBind,
    final int nextVariable,
    final JavaClass classBeingPatched
  ){
    myRootContainer = rootContainer;
    myFactory = instructionFactory;
    myConstantPoolGen = constantPoolGen;
    myClassToBind = classToBind;
    myClassBeingPatched = classBeingPatched;
    myList = instructionList;
    myComponent2TempVariable = new HashMap();
    myTempVariableCount = nextVariable;
  }

  public void generate(final ClassLoader loader) throws CodeGenerationException{
    if (myRootContainer.getComponentCount() != 1) {
      throw new CodeGenerationException("There should be only one component at the top level");
    }
    if (containsNotEmptyPanelsWithXYLayout((LwComponent)myRootContainer.getComponent(0))) {
      throw new CodeGenerationException("There are non empty panels with XY layout. Please lay them out in a grid.");
    }
    
    generateSetupCodeForComponent((LwComponent)myRootContainer.getComponent(0), loader);
  }
  
  private static boolean containsNotEmptyPanelsWithXYLayout(final LwComponent component) {
    if (!(component instanceof LwContainer)) {
      return false;
    }
    final LwContainer container = (LwContainer)component;
    if (container.getComponentCount() == 0){
      return false;
    }
    if (container.isXY()){
      return true;
    }
    for (int i=0; i < container.getComponentCount(); i++){
      if (containsNotEmptyPanelsWithXYLayout((LwComponent)container.getComponent(i))) {
        return true;
      }
    }
    return false;
  }

  private static Class getComponentClass(final LwComponent component, final ClassLoader classLoader) throws CodeGenerationException{
    String className = component.getComponentClassName();
    try {
      return Class.forName(className, false, classLoader);
    }
    catch (ClassNotFoundException e) {
      throw new CodeGenerationException("Class not found: " + className);
    }
    catch (final Throwable t) {
      throw new CodeGenerationException("Class \"" + className + "\" cannot be loaded. Reason: " + t.getMessage());
    }
  }

  private void generateSetupCodeForComponent(final LwComponent component, final ClassLoader loader) throws CodeGenerationException{
    final LwContainer parent = component.getParent();

    final int variable = getTempVariable(component);

    final Class componentClass = getComponentClass(component, loader);
               
    // create object
    createNew(componentClass);
    dup();
    invokeInit(componentClass, Type.NO_ARGS);
    myList.append(InstructionFactory.createStore(Type.OBJECT, variable));

    final String binding = component.getBinding();
    if (binding != null) {
      final Field field = findField(binding);
      if (field == null) {
        throw new CodeGenerationException("Cannot bind: field does not exist: " + myClassToBind + "." + binding);
      }

      if (field.isStatic()) {
        throw new CodeGenerationException("Cannot bind: field is static: " + myClassToBind + "." + binding);
      }
      if (field.isFinal()) {
        throw new CodeGenerationException("Cannot bind: field is final: " + myClassToBind + "." + binding);
      }

      final JavaClass componentJavaClass = Repository.lookupClass(componentClass.getName());
      if (componentJavaClass == null) {
        throw new CodeGenerationException("Class not found: " + componentClass.getName());
      }

      final Type fieldType = Type.getType(field.getSignature());
      if (!(fieldType instanceof ObjectType)) {
        throw new CodeGenerationException("Cannot bind: field is of primitive type: " + myClassToBind + "." + binding);
      }
      final String fieldClassName = ((ObjectType)fieldType).getClassName();
      final JavaClass fieldJavaClass = Repository.lookupClass(fieldClassName);
      if (fieldJavaClass == null) {
        throw new CodeGenerationException("Class not found: " + fieldClassName);
      }
      
      if (!Repository.instanceOf(componentJavaClass, fieldJavaClass)) {
        throw new CodeGenerationException("Cannot bind: Incompatible types. Cannot assign " + componentClass.getName() + " to field " + myClassToBind + "." + binding);
      }

      load(0); // this
      load(variable);
      myList.append(myFactory.createFieldAccess(myClassToBind, binding, fieldType, Constants.PUTFIELD));
    }

    // set layout to container
    if (component instanceof LwScrollPane) {
      // no layout needed
    }
    else if (component instanceof LwTabbedPane) {
      // no layout needed
    }
    else if (component instanceof LwSplitPane) {
      // no layout needed
    }
    else if (component instanceof LwContainer) {
      final LwContainer container = (LwContainer)component;

      if (container.isXY()) {
        if (container.getComponentCount() != 0) {
          throw new IllegalStateException("only empty xys are accepted");
        }
        // no layout needed
      }
      else {
        // arg 0: object
        load(variable);
        
        // arg 1: layout
        if (container.isGrid()) {
          final GridLayoutManager layout = (GridLayoutManager)container.getLayout();
          
          createNew(GridLayoutManager.class);
          dup();
          push(layout.getRowCount());
          push(layout.getColumnCount());
          newInsets(layout.getMargin());
          push(layout.getHGap());
          push(layout.getVGap());
          push(layout.isSameSizeHorizontally());
          push(layout.isSameSizeVertically());
          invokeInit(GridLayoutManager.class, new Type[]{Type.INT, Type.INT, new ObjectType(Insets.class.getName()), Type.INT, Type.INT, Type.BOOLEAN, Type.BOOLEAN});
        }
        else if (container.isXY()) {
          throw new IllegalArgumentException("XY is not supported");
        }
        else {
          throw new IllegalArgumentException("unknown layout: " + container.getLayout());
        }
        
        invokeVoidVirtual(Container.class, "setLayout", new Class[]{LayoutManager.class});
      }
    }
    
    // introspected properties
    final LwIntrospectedProperty[] introspectedProperties = component.getAssignedIntrospectedProperties();
    for (int i = 0; i < introspectedProperties.length; i++) {
      final LwIntrospectedProperty property = introspectedProperties[i];
      load(variable);

      Object value = component.getPropertyValue(property);

      // handle resource bundles
      if (property instanceof LwRbIntroStringProperty) {
        final StringDescriptor descriptor = (StringDescriptor)value;
        if (descriptor.getValue() == null) {
          push(property.getWriteMethodName());
          push(descriptor.getBundleName());
          push(descriptor.getKey());

          invokeVoidStatic(
            SupportCode.class,
            "setTextFromBundle",
            new Type[]{
              new ObjectType(JComponent.class.getName()), Type.STRING, Type.STRING, Type.STRING
            }
          );
          continue;
        }
        else {
          value = descriptor.getValue();
        }
      }

      SupportCode.TextWithMnemonic textWithMnemonic = null;
      if (
        "text".equals(property.getName()) &&
        (AbstractButton.class.isAssignableFrom(componentClass) || JLabel.class.isAssignableFrom(componentClass))
      ){
        textWithMnemonic = SupportCode.parseText((String)value);
        value = textWithMnemonic.myText;
      }
      
      final String propertyClass = property.getPropertyClassName();
      if (propertyClass.equals(Dimension.class.getName())) {
        newDimension((Dimension)value);
      }
      else if (propertyClass.equals(Integer.class.getName())){
        push(((Integer)value).intValue());
      }
      else if (propertyClass.equals(Double.class.getName())){
        push(((Double)value).doubleValue());
      }
      else if (propertyClass.equals(Boolean.class.getName())){
        push(((Boolean)value).booleanValue());
      }
      else if (propertyClass.equals(Rectangle.class.getName())) {
        newRectangle((Rectangle)value);
      }
      else if (propertyClass.equals(Insets.class.getName())) {
        newInsets((Insets)value);
      }
      else if (propertyClass.equals(String.class.getName())) {
        push((String)value);
      }
      else {
        throw new RuntimeException("unexpected property class: " + propertyClass);
      }                                                            

      final Type type;
      if (propertyClass.equals(Integer.class.getName())) {
        type = Type.INT;
      }
      else if (propertyClass.equals(Double.class.getName())) {
        type = Type.DOUBLE;
      }
      else if (propertyClass.equals(Boolean.class.getName())) {
        type = Type.BOOLEAN;
      }
      else {
        type = new ObjectType(propertyClass);
      }
      invokeVoidVirtual(componentClass, property.getWriteMethodName(), new Type[]{type});
      
      // special handling of mnemonics      

      if (textWithMnemonic == null || textWithMnemonic.myMnemonicIndex == -1) {
        continue;
      }
      
      if (AbstractButton.class.isAssignableFrom(componentClass)) {
        load(variable);
        push(textWithMnemonic.getMnemonicChar());
        invokeVoidVirtual(componentClass, "setMnemonic", new Type[]{Type.CHAR});
          
        load(variable);
        push(textWithMnemonic.myMnemonicIndex);
        myList.append(
          myFactory.createInvoke(
            SupportCode.class.getName(),
            "setDisplayedMnemonicIndex",
            Type.VOID, new Type[]{new ObjectType(JComponent.class.getName()), Type.INT},
            Constants.INVOKESTATIC
          )
        );
      }
      else if (JLabel.class.isAssignableFrom(componentClass)) {
        load(variable);
        push(textWithMnemonic.getMnemonicChar());
        invokeVoidVirtual(componentClass, "setDisplayedMnemonic", new Type[]{Type.CHAR});
        
        load(variable);
        push(textWithMnemonic.myMnemonicIndex);
        myList.append(
          myFactory.createInvoke(
            SupportCode.class.getName(),
            "setDisplayedMnemonicIndex",
            Type.VOID, new Type[]{new ObjectType(JComponent.class.getName()), Type.INT},
            Constants.INVOKESTATIC
          )
        );
      }
    }

    // add component to parent
    if (!(component.getParent() instanceof LwRootContainer)) {

      if (parent instanceof LwScrollPane) {
        load(getTempVariable(parent));
        load(variable);
        invokeVoidVirtual(JScrollPane.class, "setViewportView", new Class[]{Component.class});
      }
      else if (parent instanceof LwTabbedPane) {
        load(getTempVariable(parent));
        final LwTabbedPane.Constraints tabConstraints = (LwTabbedPane.Constraints)component.getCustomLayoutConstraints();
        if (tabConstraints == null){
          throw new IllegalArgumentException("tab constraints cannot be null: " + component.getId());
        }
        push(tabConstraints.myTitle);
        load(variable);
        invokeVoidVirtual(JTabbedPane.class, "addTab", new Class[]{String.class, Component.class});
      }
      else if (parent instanceof LwSplitPane) {
        load(getTempVariable(parent));
        load(variable);
        if (LwSplitPane.POSITION_LEFT.equals(component.getCustomLayoutConstraints())) {
          invokeVoidVirtual(JSplitPane.class, "setLeftComponent", new Class[]{Component.class});
        }
        else {
          invokeVoidVirtual(JSplitPane.class, "setRightComponent", new Class[]{Component.class});
        }
      }
      else {
        load(getTempVariable(parent));
        load(variable);
        addNewGridConstraints(component);
        invokeVoidVirtual(Container.class, "add", new Class[]{Component.class, Object.class});
      }
    }

    if (component instanceof LwContainer) {
      final LwContainer container = (LwContainer)component;

      // border

      final BorderType borderType = container.getBorderType();
      final StringDescriptor borderTitle = container.getBorderTitle();
      final String borderFactoryMethodName = borderType.getBorderFactoryMethodName();

      final boolean borderNone = borderType.equals(BorderType.NONE);
      if (!borderNone || borderTitle != null) {
        // object to invoke setBorder
        load(variable);

        if (!borderNone) {
          // create border itself
          myList.append(myFactory.createInvoke(
            BorderFactory.class.getName(),
            borderFactoryMethodName,
            new ObjectType(Border.class.getName()),
            Type.NO_ARGS, 
            Constants.INVOKESTATIC
          ));
          // use BorderFactory.createTitledBorder(Border, String)
          push(borderTitle);
          myList.append(myFactory.createInvoke(
            BorderFactory.class.getName(),
            "createTitledBorder",
            new ObjectType(TitledBorder.class.getName()),
            new Type[] {new ObjectType(Border.class.getName()), new ObjectType(String.class.getName())},
            Constants.INVOKESTATIC
          ));
        }
        else {
          // use BorderFactory.createTitledBorder(String)
          push(borderTitle);
          myList.append(myFactory.createInvoke(
            BorderFactory.class.getName(),
            "createTitledBorder",
            new ObjectType(TitledBorder.class.getName()),
            new Type[] {new ObjectType(String.class.getName())}, 
            Constants.INVOKESTATIC
          ));
        }
        
        // set border
        invokeVoidVirtual(JComponent.class, "setBorder", new Class[]{Border.class});
      }

      for (int i = 0; i < container.getComponentCount(); i++) {
        generateSetupCodeForComponent((LwComponent)container.getComponent(i), loader);
      }
    }
  }

  /**
   * @return variable idx
   */
  private int getTempVariable(final LwComponent component){
    if (myComponent2TempVariable.containsKey(component)){
      return ((Integer)myComponent2TempVariable.get(component)).intValue();
    }

    final int result = ++myTempVariableCount;
    myComponent2TempVariable.put(component, new Integer(result));
    return result;
  }

  private void addNewGridConstraints(final LwComponent component){
    final GridConstraints constraints = component.getConstraints();

    createNew(GridConstraints.class);
    dup();
    push(constraints.getRow());
    push(constraints.getColumn());
    push(constraints.getRowSpan());
    push(constraints.getColSpan());
    push(constraints.getAnchor());
    push(constraints.getFill());
    push(constraints.getHSizePolicy());
    push(constraints.getVSizePolicy());
    newDimensionOrNull(constraints.myMinimumSize);
    newDimensionOrNull(constraints.myPreferredSize);
    newDimensionOrNull(constraints.myMaximumSize);

    final ObjectType dimensionType = new ObjectType(Dimension.class.getName());
    invokeInit(
      GridConstraints.class, 
      new Type[]{Type.INT, Type.INT, Type.INT, Type.INT, Type.INT, Type.INT, Type.INT, Type.INT, 
                 dimensionType, dimensionType, dimensionType}
    );
  }

  private void newDimensionOrNull(final Dimension dimension) {
    if (dimension.width == -1 && dimension.height == -1) {
      pushNull();
    }
    else {
      newDimension(dimension);
    }
  }

  private void pushNull() {
    myList.append(new ACONST_NULL());
  }

  private void newDimension(final Dimension dimension) {
    createNew(Dimension.class);
    dup();
    push(dimension.width);
    push(dimension.height);
    invokeInit(Dimension.class, new Type[]{Type.INT, Type.INT});
  }

  private void newInsets(final Insets insets){
    createNew(Insets.class);
    dup();
    push(insets.top);
    push(insets.left);
    push(insets.bottom);
    push(insets.right);
    invokeInit(Insets.class, new Type[]{Type.INT, Type.INT, Type.INT, Type.INT});
  }
  
  private void newRectangle(final Rectangle rectangle){
    createNew(Insets.class);
    dup();
    push(rectangle.x);
    push(rectangle.y);
    push(rectangle.width);
    push(rectangle.height);
    invokeInit(Rectangle.class, new Type[]{Type.INT, Type.INT, Type.INT, Type.INT});
  }
  
  private void push(final int value) {
    myList.append(new PUSH(myConstantPoolGen, value));
  }

  private void push(final double value) {
    myList.append(new PUSH(myConstantPoolGen, value));
  }

  private void push(final char value) {
    myList.append(new PUSH(myConstantPoolGen, value));
  }

  private void push(final boolean value) {
    myList.append(new PUSH(myConstantPoolGen, value));
  }

  private void push(final String value) {
    myList.append(new PUSH(myConstantPoolGen, value));
  }

  private void push(final StringDescriptor descriptor) {
    if (descriptor == null) {
      pushNull();
    }
    else if (descriptor.getValue() != null) {
      push(descriptor.getValue());
    }
    else {
      push(descriptor.getBundleName());
      push(descriptor.getKey());
      myList.append(myFactory.createInvoke(SupportCode.class.getName(), "getResourceString", Type.STRING, new Type[]{Type.STRING, Type.STRING}, Constants.INVOKESTATIC));
    }
  }

  private void dup() {
    myList.append(InstructionConstants.DUP);
  }
  
  private void load(final int variable) {
    myList.append(InstructionFactory.createLoad(Type.OBJECT, variable));
  }
  
  private void invokeVoidVirtual(final Class aClass, final String methodName, final Class[] parameters) {
    final Type[] types = new Type[parameters.length];
    for (int i = 0; i < types.length; i++) {
      types[i] = new ObjectType(parameters[i].getName());
    }
    invokeVoidVirtual(aClass, methodName, types);
  }

  private void invokeVoidVirtual(final Class aClass, final String methodName, final Type[] types){
    myList.append(myFactory.createInvoke(aClass.getName(), methodName, Type.VOID, types, Constants.INVOKEVIRTUAL));
  }

  private void invokeVoidStatic(final Class aClass, final String methodName, final Type[] types){
    myList.append(myFactory.createInvoke(aClass.getName(), methodName, Type.VOID, types, Constants.INVOKESTATIC));
  }

  private void createNew(final Class aClass) {
    myList.append(myFactory.createNew(aClass.getName()));
  }
  
  private void invokeInit(final Class aClass, final Type[] parameters) {
    myList.append(myFactory.createInvoke(aClass.getName(), "<init>", Type.VOID, parameters, Constants.INVOKESPECIAL));
  }
  
  private Field findField(final String fieldName) {
    return findField(myClassBeingPatched, fieldName);
  }

  private static Field findField(final JavaClass aClass, final String fieldName){
    final Field[] fields = aClass.getFields();
    for (int i = 0; i < fields.length; i++) {
      final Field field = fields[i];
      if (fieldName.equals(field.getName())) {
        return field; 
      }
    }

    return null;
  }
}
