/*
 * Copyright (c) 2004 JetBrains s.r.o. All  Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 *
 * Neither the name of JetBrains or IntelliJ IDEA
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. JETBRAINS AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL JETBRAINS OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF JETBRAINS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 */
package com.intellij.uiDesigner.lw;

/**
 * @author Vladimir Kondratyev
 */
public final class StringDescriptor {
  /**
   * Name of resource bundle
   */
  private final String myBundleName;
  /**
   * Key in the resource bundle
   */
  private final String myKey;
  /**
   * Value has sense if it's calculated not via resource bundle
   */
  private final String myValue;
  /**
   * Cached resolved value. We need it here to speed up property inspector
   * painting.
   */
  private String myResolvedValue;

  private StringDescriptor(final String value){
    if (value == null) {
      throw new IllegalArgumentException("value cannot be null");
    }
    myBundleName = null;
    myKey = null;
    myValue = value;
  }

  public StringDescriptor(final String bundleName, final String key) {
    if (bundleName == null) {
      throw new IllegalArgumentException("bundleName cannot be null");
    }
    if (key == null) {
      throw new IllegalArgumentException("key cannot be null");
    }
    myBundleName = bundleName;
    myKey = key;
    myValue = null;
  }

  /**
   * Creates "trivial" StringDescriptor.
   */
  public static StringDescriptor create(final String value){
    return value != null ? new StringDescriptor(value) : null;
  }

  /**
   * @return not <code>null</code> value if this is "trivial" StringDescriptor.
   * If StringDescriptor is "trivial" then {@link #getBundleName()} and {@link #getKey()}
   * return <code>null</code>.
   */
  public String getValue(){
    return myValue;
  }

  /**
   * @return not <code>null</code> value if this is non "trivial" StringDescriptor.
   */
  public String getBundleName() {
    return myBundleName;
  }

  /**
   * @return not <code>null</code> value if this is non "trivial" StringDescriptor.
   */
  public String getKey() {
    return myKey;
  }

  /**
   * @return can be null
   */
  public String getResolvedValue() {
    return myResolvedValue;
  }

  /**
   * @param resolvedValue can be null
   */
  public void setResolvedValue(final String resolvedValue) {
    myResolvedValue = resolvedValue;
  }

  public boolean equals(final Object o) {
    if (this == o) return true;
    if (!(o instanceof StringDescriptor)) return false;

    final StringDescriptor descriptor = (StringDescriptor)o;

    if (myBundleName != null ? !myBundleName.equals(descriptor.myBundleName) : descriptor.myBundleName != null) return false;
    if (myKey != null ? !myKey.equals(descriptor.myKey) : descriptor.myKey != null) return false;
    if (myValue != null ? !myValue.equals(descriptor.myValue) : descriptor.myValue != null) return false;

    return true;
  }

  public int hashCode() {
    int result;
    result = (myBundleName != null ? myBundleName.hashCode() : 0);
    result = 29 * result + (myKey != null ? myKey.hashCode() : 0);
    result = 29 * result + (myValue != null ? myValue.hashCode() : 0);
    return result;
  }
}
